data modify storage sniffer_test:log zip_first set value 1
data modify storage sniffer_test:log zip_second set value 1
